local mod = get_mod("commodores_vestures_improved")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = false,
}
